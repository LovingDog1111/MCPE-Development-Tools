https://github.com/LovingDog1111

this file allows you to update vtable offsets quickly. This is not 100% accurate all the time, it is just simple math that might not work with all classes. 