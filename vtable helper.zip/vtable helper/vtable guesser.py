def guess_new_vtable(old_known, new_known, old_target):
    """
    Guess the new vtable number based on known old->new mapping.
    """
    delta = new_known - old_known
    new_target = old_target + delta
    return new_target

def main():
    print("=== VTableHelper ===")
    print("Estimate new vtable numbers based on known mappings.\n")

    try:
        old_known = int(input("Enter the OLD vtable number of a known function: "))
        new_known = int(input("Enter the NEW vtable number of that function: "))
        old_target = int(input("Enter the OLD vtable number you want to estimate: "))

        estimated = guess_new_vtable(old_known, new_known, old_target)
        print(f"\nEstimated NEW vtable number for {old_target} is: {estimated}")

    except ValueError:
        print("Please enter valid integer numbers.")

    input("\nPress Enter to exit...") 

if __name__ == "__main__":
    main()
