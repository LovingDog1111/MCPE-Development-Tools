https://github.com/LovingDog1111

this file will remove all comments from any .h and .cpp in a folder directory (this covers folders within the folder) however will skip lib folders.