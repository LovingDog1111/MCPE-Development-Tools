import os
import time

GREEN = "\033[92m"
RED = "\033[91m"
RESET = "\033[0m"

IGNORED_FOLDERS = {"libs", "libhat", "imgui", "minhook", "renderer"} #this is because this code is shit and tries to delete some things but it only really happens with things like this

def remove_comments(code: str) -> str:
    """
    Safely remove C++ comments from code.
    Handles // and /* */ comments.
    Quotes inside comments are ignored.
    """
    result = []
    i = 0
    n = len(code)
    in_string = False
    string_char = ''
    in_single_comment = False
    in_multi_comment = False

    while i < n:
        char = code[i]
        next_char = code[i+1] if i+1 < n else ''

        if in_single_comment:
            if char in ('\n', '\r'):
                in_single_comment = False
                result.append(char)
            i += 1
            continue

        if in_multi_comment:
            if char == '*' and next_char == '/':
                in_multi_comment = False
                i += 2
            else:
                i += 1
            continue

        if not in_string and char == '/' and next_char == '/':
            in_single_comment = True
            i += 2
            continue

        if not in_string and char == '/' and next_char == '*':
            in_multi_comment = True
            i += 2
            continue

        if in_string:
            result.append(char)
            if char == string_char and (i == 0 or code[i-1] != '\\'):
                in_string = False
            i += 1
            continue

        if char in ('"', "'"):
            in_string = True
            string_char = char
            result.append(char)
            i += 1
            continue

        result.append(char)
        i += 1

    return ''.join(result)

def should_ignore(filepath):
    """Check if the file is in an ignored folder."""
    parts = [p.lower() for p in filepath.split(os.sep)]
    for ignored in IGNORED_FOLDERS:
        if ignored.lower() in parts:
            return True
    return False

def process_file(filepath, count, total, delay=0.05):
    """Read, remove comments, overwrite file, and delay."""
    if should_ignore(filepath):
        print(f"{RED}[{count}/{total}] Skipping (ignored folder): {filepath}{RESET}")
        return

    try:
        print(f"{GREEN}[{count}/{total}] Processing: {filepath}{RESET}")
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            code = f.read()
        cleaned_code = remove_comments(code)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(cleaned_code)
        time.sleep(delay)
    except Exception as e:
        print(f"{RED}[{count}/{total}] Failed: {filepath} ({e}){RESET}")

def main():
    print("=== Recursive C++ Comment Remover ===")
    folder_path = input("Enter folder path: ").strip()

    if folder_path.startswith('"') and folder_path.endswith('"'):
        folder_path = folder_path[1:-1]

    if not os.path.isdir(folder_path):
        print(f"{RED}Folder not found!{RESET}")
        input("\nPress Enter to exit...")
        return

    files_to_process = []
    for root, _, files in os.walk(folder_path):
        for file in files:
            if file.endswith(('.cpp', '.h')):
                filepath = os.path.join(root, file)
                files_to_process.append(filepath)

    total_files = len(files_to_process)
    print(f"Found {total_files} files to process.\n")

    for idx, filepath in enumerate(files_to_process, start=1):
        process_file(filepath, idx, total_files, delay=0.05)

    print(f"\nAll C++ comments removed safely (ignored folders preserved)!")
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
